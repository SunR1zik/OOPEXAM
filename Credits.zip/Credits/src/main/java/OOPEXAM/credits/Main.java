package OOPEXAM.credits;

import OOPEXAM.credits.controller.MainController;
import OOPEXAM.credits.view.ConsoleView;


public class Main {
	
	public static void main(String... args) {
		ConsoleView consoleView = new ConsoleView();
		MainController mainController = new MainController(consoleView);
		mainController.process();

	}
	
}
