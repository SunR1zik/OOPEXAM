package OOPEXAM.credits.controller;

import java.util.ArrayList;
import java.util.List;

import OOPEXAM.credits.entity.Credit;
import OOPEXAM.credits.entity.Credits;
import OOPEXAM.credits.view.ConsoleView;
import OOPEXAM.credits.view.TextConstant;

public class CreditController {
	
	private ConsoleView consoleView;
	
	public CreditController(ConsoleView consoleView) {
		this.consoleView = consoleView;
	}
	

	public List<Credit> getAllCreditsTerms() {
		List<Credit> creditsTerms = new ArrayList<>();
		
		for (Credits c : Credits.values()) {
			creditsTerms.add(c.getCreditTerms());
		}
		
		return creditsTerms;
	}

	public List<Credit> getCreditsTermsByPurposeAndTerm(List<Credit> credits) {
		Credit.Purpose purposeCriteria = inputCreditPurposeWithScanner();
		int termCriteria = inputCreditTermWithScanner(credits);
		
		return getCreditsTermsByCriteria(credits, purposeCriteria, termCriteria);
	}
	

	public List<Credit> getCreditsTermsByCriteria(List<Credit> credits, 
			Credit.Purpose purposeCriteria,
			int termCriteria) {
		
		List<Credit> res = new ArrayList<>();
		
		if (credits == null) {
			return res;
		}
		
		for (Credit credit : credits) {
			if (credit.getPurpose().equals(purposeCriteria) && 
					credit.getTermInMonths() == termCriteria) {
				res.add(credit);
			}
		}
		
		return res;
	}
	

	private Credit.Purpose inputCreditPurposeWithScanner() {
		
		Credit.Purpose[] purposes = Credit.Purpose.values();
		
		for (int i = 0; i < purposes.length; i++) {
			consoleView.printMessage(i + " - " + purposes[i]);
		}
		
		int purposeId = new UtillityController(consoleView)
				.inputIntValueWithScannerInDiapason(TextConstant.CREDIT_PURPOSE, 0, purposes.length - 1);
		
		return purposes[purposeId];
		
	}
	

	private int inputCreditTermWithScanner(List<Credit> credits) {
		
		List<Integer> terms = new ArrayList<>();
		
		for (Credit credit : credits) {
			int term = credit.getTermInMonths();
			
			if (!terms.contains(term)) {
				terms.add(term);
			}
		}
		
		for (int i = 0; i < terms.size(); i++) {
			consoleView.printMessage(i + " - " + terms.get(i));
		}
		
		int term = new UtillityController(consoleView)
				.inputIntValueWithScannerInDiapason(TextConstant.CREDIT_TERM_IN_MONTHS, 0, terms.size() - 1);
		
		return terms.get(term);
		
	}
	
}
