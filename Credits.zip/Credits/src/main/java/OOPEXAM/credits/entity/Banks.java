package OOPEXAM.credits.entity;

import OOPEXAM.credits.model.Bank;

public enum Banks {
	
	BIS(new Bank("банк инвест")),
	KREDO(new Bank("Кредит банк"));
	
	private Bank bank;
	
	private Banks(Bank bank) {
		this.bank = bank;
	}
	
	public Bank getBank() {
		return bank;
	}
	
}
