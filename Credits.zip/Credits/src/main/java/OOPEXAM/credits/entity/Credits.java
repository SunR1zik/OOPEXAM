package OOPEXAM.credits.entity;

import java.math.BigDecimal;

public enum Credits {
	
	BIS_MORTGAGE_1(
			new Credit(
					Banks.BIS.getBank(),
					Credit.Purpose.MORTGAGE,
					new BigDecimal("37"),
					36,
					new BigDecimal("8000000"))
			),
	BIS_MORTGAGE_2(
			new Credit(
					Banks.BIS.getBank(),
					Credit.Purpose.MORTGAGE,
					new BigDecimal("36"),
					120,
					new BigDecimal("7000000"))
			),
	KREDO_MORTGAGE_1(
			new Credit(
					Banks.KREDO.getBank(),
					Credit.Purpose.MORTGAGE,
					new BigDecimal("21"),
					36,
					new BigDecimal("2000000"))
			),
	KREDO_CONSUMER_1(
			new InstallmentPlan(
					Banks.KREDO.getBank(),
					Credit.Purpose.CONSUMER,
					new BigDecimal("40"),
					36,
					new BigDecimal("50000"),
					12)
			),
	KREDO_CONSUMER_2(
			new InstallmentPlan(
					Banks.KREDO.getBank(),
					Credit.Purpose.CONSUMER,
					new BigDecimal("50"),
					60,
					new BigDecimal("70000"),
					24)
			);
	
	private Credit creditTerms;
	
	private Credits(Credit creditTerms) {
		creditTerms.getBank().addCreditTerms(creditTerms);
		this.creditTerms = creditTerms;
	}

	public Credit getCreditTerms() {
		return creditTerms;
	}
	
}
